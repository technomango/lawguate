<?php
return  [
    'PayPal'=>App\Payment\Paypal::class,
    'Stripe'=>App\Payment\Stripe::class,
];
