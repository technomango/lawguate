<?php

namespace App\Models;

use App\Traits\Tenantable;
use Illuminate\Database\Eloquent\Model;

class PutlistDate extends Model
{
    use Tenantable;
}
