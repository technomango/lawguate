<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddZoomModuleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
//        $modules = [];
//        $modules[] = ['name' => 'Zoom', 'details' => "This is Zoom Module For Virtual Meeting. Thanks for using.", 'created_at' => now(), 'updated_at' => now(), 'order' => 1];
//
//        DB::table('modules')->insert(
//            $modules
//        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
