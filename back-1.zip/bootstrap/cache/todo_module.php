<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Todo\\Providers\\TodoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Todo\\Providers\\TodoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);