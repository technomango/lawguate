<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\EmailtoCL\\Providers\\EmailtoCLServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\EmailtoCL\\Providers\\EmailtoCLServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);