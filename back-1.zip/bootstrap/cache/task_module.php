<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Task\\Providers\\TaskServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Task\\Providers\\TaskServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);