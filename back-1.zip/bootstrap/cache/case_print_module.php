<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CasePrint\\Providers\\CasePrintServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CasePrint\\Providers\\CasePrintServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);