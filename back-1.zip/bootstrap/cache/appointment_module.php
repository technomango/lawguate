<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Appointment\\Providers\\AppointmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Appointment\\Providers\\AppointmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);