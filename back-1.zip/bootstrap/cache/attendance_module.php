<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Attendance\\Providers\\AttendanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Attendance\\Providers\\AttendanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);