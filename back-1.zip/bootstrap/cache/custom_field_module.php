<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomField\\Providers\\CustomFieldServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomField\\Providers\\CustomFieldServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);