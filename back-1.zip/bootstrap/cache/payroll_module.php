<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Payroll\\Providers\\PayrollServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Payroll\\Providers\\PayrollServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);