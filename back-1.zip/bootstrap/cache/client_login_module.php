<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ClientLogin\\Providers\\ClientLoginServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ClientLogin\\Providers\\ClientLoginServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);