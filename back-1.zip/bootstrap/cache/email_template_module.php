<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\EmailTemplate\\Providers\\EmailTemplateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\EmailTemplate\\Providers\\EmailTemplateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);