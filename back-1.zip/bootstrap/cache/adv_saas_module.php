<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdvSaas\\Providers\\AdvSaasServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdvSaas\\Providers\\AdvSaasServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);