<?php

return [
    'name' => 'Leave'
];
