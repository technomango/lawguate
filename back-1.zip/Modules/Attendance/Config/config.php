<?php

return [
    'name' => 'Attendance'
];
