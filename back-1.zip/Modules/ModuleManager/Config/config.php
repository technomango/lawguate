<?php

return [
    'name' => 'ModuleManager'
];
