<?php

namespace Modules\ModuleManager\Entities;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    protected $fillable = [];
}
