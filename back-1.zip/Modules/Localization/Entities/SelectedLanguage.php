<?php

namespace Modules\Localization\Entities;

use Illuminate\Database\Eloquent\Model;

class SelectedLanguage extends Model
{
    protected $fillable = ['id', 'organization_id'];
}
