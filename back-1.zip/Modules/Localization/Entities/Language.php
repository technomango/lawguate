<?php

namespace Modules\Localization\Entities;

use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $guarded = [];
}
